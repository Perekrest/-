function[T] = main1(x,t)

h = x(2)-x(1);
n = length(x)-1;
nn = length(t)-1;
T = [];
dt = t(2)-t(1);




for i = 1:n+1
    T(1,i) = 2*x(i)*(x(i)+0.2)+0.4;
end
for i = 1:nn+1
    T(i,1) = 2*t(i)+0.4;
    T(i,n+1) = 1.36;
end


for  i = 2:nn+1
   for j = 2:n
   T(i,j) = (dt/(h^2))*(T(i-1,j+1)-2*T(i-1,j)+T(i-1,j-1)) + T(i-1,j);
   end
end
end





