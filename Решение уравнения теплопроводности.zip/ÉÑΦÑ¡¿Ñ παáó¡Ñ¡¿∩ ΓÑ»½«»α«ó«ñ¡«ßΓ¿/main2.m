function[T] = main2(x,t)

n = length(x)-1;
nn = length(t)-1;
T = [];
A = [];
r = [];
d = [];

dt = t(2)-t(1);
h = x(2)-x(1);

for i = 1:n+1
    T(1,i) = 2*x(i)*(x(i)+0.2)+0.4;
end
for i = 1:nn+1
    T(i,1) = 2*t(i)+0.4;
    T(i,n+1) = 1.36;
end

a  = 1/(h^2);
b = (h^2+2*dt)/(dt*h^2);
c = a;

for i = 2:n
   A(i,i) = b;
   A(i,i-1) = -a;
   A(i,i+1) = -c;
   A(1,1) = b;
   A(1,2) = -c;
   A(n+1,n+1) = b;
   A(n+1,n) = -a;
end

 for i = 2:nn+1
     for j = 1:n+1
         r(j) = (1/dt)*T(i-1,j);
     end
     d = progon(A,r);
     for j = 2:n
         T(i,j) = d(j);
     end
     
 end
