function[x] = progon(A, r) 
    betta = [];
    lamb = [];
    x = [];
    n = length(r);
    
    for i= 2:1:(n-1)
        betta(1) = - A(1,2)/A(1,1);
        lamb(1) = r(1)/A(1,1);
        betta(i) = -A(i,i+1)/(A(i,i-1)*betta(i-1)+A(i,i));
        lamb(i) = (r(i)-A(i,i-1)*lamb(i-1))/(A(i,i-1)*betta(i-1)+A(i,i));
    end
    
    betta(n) = 0;
    lamb(n) = (r(n)-A(n,n-1)*lamb(n-1))/(A(n,n-1)*betta(n-1)+A(n,n));
    x(n) = lamb(n);

    for j = n-1:-1:1
        x(n) = lamb(n); 
        x(j) = betta(j)*x(j+1)+lamb(j);
    end
end
